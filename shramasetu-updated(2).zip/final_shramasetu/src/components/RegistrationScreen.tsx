import { useMemo, useState, type ReactNode } from 'react';
import { ArrowLeft, ArrowRight, CheckCircle2, Globe2, Languages, UserRound, BriefcaseBusiness, MapPin, Phone, GraduationCap } from 'lucide-react';
import { useApp } from '@/AppContext';
import { Card, Button, ScreenHeader } from './ui';
import { LANGUAGES, type LangCode } from '@/i18n';
import type { Role, Gender } from '@/types';

const registrationCopy: Record<LangCode, Record<string, string>> = {
  en: { title: 'Registration', subtitle: 'Create your demo worker or contractor profile', chooseRole: 'Account type', labourer: 'Labourer', contractor: 'Contractor', language: 'Preferred language', fullName: 'Full name', phone: 'Mobile number', skill: 'Primary skill', experience: 'Experience', qualification: 'Qualification', languages: 'Languages spoken', location: 'Current location', wage: 'Expected monthly income', company: 'Company / business name', workers: 'Workers you manage', emergency: 'Emergency contact', example: 'Use example', continue: 'Create profile', back: 'Back', demo: 'Prototype only — no real registration, payments, insurance or payroll are processed.', skillExample: 'Example: Mason', nameExample: 'Example: Ravi Kumar', qualificationExample: 'Example: ITI / Diploma / Class 10', locationExample: 'Example: Mysuru, Karnataka', companyExample: 'Example: Kumar Constructions', emergencyExample: 'Example: Suresh Kumar — 9123456780', wageExample: 'Example: ₹18,000 / month', workersExample: 'Example: 12' },
  hi: { title: 'पंजीकरण', subtitle: 'अपना डेमो मजदूर या ठेकेदार प्रोफ़ाइल बनाएं', chooseRole: 'खाता प्रकार', labourer: 'मजदूर', contractor: 'ठेकेदार', language: 'पसंदीदा भाषा', fullName: 'पूरा नाम', phone: 'मोबाइल नंबर', skill: 'मुख्य कौशल', experience: 'अनुभव', qualification: 'योग्यता', languages: 'बोली जाने वाली भाषाएं', location: 'वर्तमान स्थान', wage: 'अपेक्षित मासिक आय', company: 'कंपनी / व्यवसाय का नाम', workers: 'आपके अधीन मजदूर', emergency: 'आपातकालीन संपर्क', example: 'उदाहरण भरें', continue: 'प्रोफ़ाइल बनाएं', back: 'वापस', demo: 'केवल प्रोटोटाइप — कोई वास्तविक पंजीकरण, भुगतान, बीमा या पेरोल नहीं होता।', skillExample: 'उदाहरण: राजमिस्त्री', nameExample: 'उदाहरण: रवि कुमार', qualificationExample: 'उदाहरण: ITI / डिप्लोमा / कक्षा 10', locationExample: 'उदाहरण: मैसूर, कर्नाटक', companyExample: 'उदाहरण: कुमार कंस्ट्रक्शन्स', emergencyExample: 'उदाहरण: सुरेश कुमार — 9123456780', wageExample: 'उदाहरण: ₹18,000 / माह', workersExample: 'उदाहरण: 12' },
  kn: { title: 'ನೋಂದಣಿ', subtitle: 'ನಿಮ್ಮ ಡೆಮೊ ಕಾರ್ಮಿಕ ಅಥವಾ ಗುತ್ತಿಗೆದಾರ ಪ್ರೊಫೈಲ್ ರಚಿಸಿ', chooseRole: 'ಖಾತೆ ಪ್ರಕಾರ', labourer: 'ಕಾರ್ಮಿಕ', contractor: 'ಗುತ್ತಿಗೆದಾರ', language: 'ಆದ್ಯತೆಯ ಭಾಷೆ', fullName: 'ಪೂರ್ಣ ಹೆಸರು', phone: 'ಮೊಬೈಲ್ ಸಂಖ್ಯೆ', skill: 'ಮುಖ್ಯ ಕೌಶಲ್ಯ', experience: 'ಅನುಭವ', qualification: 'ಅರ್ಹತೆ', languages: 'ಮಾತನಾಡುವ ಭಾಷೆಗಳು', location: 'ಪ್ರಸ್ತುತ ಸ್ಥಳ', wage: 'ನಿರೀಕ್ಷಿತ ಮಾಸಿಕ ಆದಾಯ', company: 'ಕಂಪನಿ / ವ್ಯವಹಾರದ ಹೆಸರು', workers: 'ನಿಮ್ಮ ಅಡಿಯಲ್ಲಿ ಕಾರ್ಮಿಕರು', emergency: 'ತುರ್ತು ಸಂಪರ್ಕ', example: 'ಉದಾಹರಣೆ ತುಂಬಿ', continue: 'ಪ್ರೊಫೈಲ್ ರಚಿಸಿ', back: 'ಹಿಂದೆ', demo: 'ಮೂಲಮಾದರಿ ಮಾತ್ರ — ನಿಜವಾದ ನೋಂದಣಿ, ಪಾವತಿ, ವಿಮೆ ಅಥವಾ ಪೇರೋಲ್ ನಡೆಯುವುದಿಲ್ಲ.', skillExample: 'ಉದಾಹರಣೆ: ಮೇಸ್ತ್ರಿ', nameExample: 'ಉದಾಹರಣೆ: ರವಿ ಕುಮಾರ್', qualificationExample: 'ಉದಾಹರಣೆ: ITI / ಡಿಪ್ಲೊಮಾ / 10ನೇ ತರಗತಿ', locationExample: 'ಉದಾಹರಣೆ: ಮೈಸೂರು, ಕರ್ನಾಟಕ', companyExample: 'ಉದಾಹರಣೆ: ಕುಮಾರ್ ಕನ್‌ಸ್ಟ್ರಕ್ಷನ್ಸ್', emergencyExample: 'ಉದಾಹರಣೆ: ಸುರೇಶ್ ಕುಮಾರ್ — 9123456780', wageExample: 'ಉದಾಹರಣೆ: ₹18,000 / ತಿಂಗಳು', workersExample: 'ಉದಾಹರಣೆ: 12' },
  ta: { title: 'பதிவு', subtitle: 'உங்கள் டெமோ தொழிலாளர் அல்லது ஒப்பந்ததாரர் சுயவிவரத்தை உருவாக்கவும்', chooseRole: 'கணக்கு வகை', labourer: 'தொழிலாளர்', contractor: 'ஒப்பந்ததாரர்', language: 'விருப்ப மொழி', fullName: 'முழு பெயர்', phone: 'மொபைல் எண்', skill: 'முக்கிய திறன்', experience: 'அனுபவம்', qualification: 'தகுதி', languages: 'பேசும் மொழிகள்', location: 'தற்போதைய இடம்', wage: 'எதிர்பார்க்கும் மாத வருமானம்', company: 'நிறுவனம் / வணிக பெயர்', workers: 'உங்களின் தொழிலாளர்கள்', emergency: 'அவசர தொடர்பு', example: 'உதாரணம் நிரப்பு', continue: 'சுயவிவரத்தை உருவாக்கு', back: 'பின்', demo: 'முன்மாதிரி மட்டும் — உண்மையான பதிவு, பணம், காப்பீடு அல்லது ஊதியச் செயலாக்கம் நடைபெறாது.', skillExample: 'உதாரணம்: மேஸ்திரி', nameExample: 'உதாரணம்: ரவி குமார்', qualificationExample: 'உதாரணம்: ITI / டிப்ளோமா / 10ஆம் வகுப்பு', locationExample: 'உதாரணம்: மைசூரு, கர்நாடகா', companyExample: 'உதாரணம்: குமார் கன்ஸ்ட்ரக்ஷன்ஸ்', emergencyExample: 'உதாரணம்: சுரேஷ் குமார் — 9123456780', wageExample: 'உதாரணம்: ₹18,000 / மாதம்', workersExample: 'உதாரணம்: 12' },
  te: { title: 'నమోదు', subtitle: 'మీ డెమో కార్మికుడు లేదా కాంట్రాక్టర్ ప్రొఫైల్ సృష్టించండి', chooseRole: 'ఖాతా రకం', labourer: 'కార్మికుడు', contractor: 'కాంట్రాక్టర్', language: 'ఇష్టమైన భాష', fullName: 'పూర్తి పేరు', phone: 'మొబైల్ నంబర్', skill: 'ప్రధాన నైపుణ్యం', experience: 'అనుభవం', qualification: 'అర్హత', languages: 'మాట్లాడే భాషలు', location: 'ప్రస్తుత స్థానం', wage: 'అంచనా నెలవారీ ఆదాయం', company: 'కంపెనీ / వ్యాపారం పేరు', workers: 'మీ కింద కార్మికులు', emergency: 'అత్యవసర సంప్రదింపు', example: 'ఉదాహరణ నింపండి', continue: 'ప్రొఫైల్ సృష్టించండి', back: 'వెనుకకు', demo: 'ప్రోటోటైప్ మాత్రమే — నిజమైన నమోదు, చెల్లింపులు, బీమా లేదా పేరోల్ జరగదు.', skillExample: 'ఉదాహరణ: మేస్త్రీ', nameExample: 'ఉదాహరణ: రవి కుమార్', qualificationExample: 'ఉదాహరణ: ITI / డిప్లొమా / 10వ తరగతి', locationExample: 'ఉదాహరణ: మైసూరు, కర్ణాటక', companyExample: 'ఉదాహరణ: కుమార్ కన్‌స్ట్రక్షన్స్', emergencyExample: 'ఉదాహరణ: సురేష్ కుమార్ — 9123456780', wageExample: 'ఉదాహరణ: ₹18,000 / నెల', workersExample: 'ఉదాహరణ: 12' },
  mr: { title: 'नोंदणी', subtitle: 'तुमचे डेमो कामगार किंवा कंत्राटदार प्रोफाइल तयार करा', chooseRole: 'खाते प्रकार', labourer: 'कामगार', contractor: 'कंत्राटदार', language: 'पसंतीची भाषा', fullName: 'पूर्ण नाव', phone: 'मोबाईल नंबर', skill: 'मुख्य कौशल्य', experience: 'अनुभव', qualification: 'शैक्षणिक पात्रता', languages: 'बोलल्या जाणाऱ्या भाषा', location: 'सध्याचे ठिकाण', wage: 'अपेक्षित मासिक उत्पन्न', company: 'कंपनी / व्यवसायाचे नाव', workers: 'तुमच्याकडील कामगार', emergency: 'आपत्कालीन संपर्क', example: 'उदाहरण भरा', continue: 'प्रोफाइल तयार करा', back: 'मागे', demo: 'फक्त प्रोटोटाइप — प्रत्यक्ष नोंदणी, पेमेंट, विमा किंवा पेरोल चालवले जात नाही.', skillExample: 'उदाहरण: गवंडी', nameExample: 'उदाहरण: रवी कुमार', qualificationExample: 'उदाहरण: ITI / डिप्लोमा / 10वी', locationExample: 'उदाहरण: म्हैसूर, कर्नाटक', companyExample: 'उदाहरण: कुमार कन्स्ट्रक्शन्स', emergencyExample: 'उदाहरण: सुरेश कुमार — 9123456780', wageExample: 'उदाहरण: ₹18,000 / महिना', workersExample: 'उदाहरण: 12' },
  bn: { title: 'নিবন্ধন', subtitle: 'আপনার ডেমো শ্রমিক বা ঠিকাদার প্রোফাইল তৈরি করুন', chooseRole: 'অ্যাকাউন্টের ধরন', labourer: 'শ্রমিক', contractor: 'ঠিকাদার', language: 'পছন্দের ভাষা', fullName: 'পুরো নাম', phone: 'মোবাইল নম্বর', skill: 'প্রধান দক্ষতা', experience: 'অভিজ্ঞতা', qualification: 'যোগ্যতা', languages: 'কথ্য ভাষা', location: 'বর্তমান অবস্থান', wage: 'প্রত্যাশিত মাসিক আয়', company: 'কোম্পানি / ব্যবসার নাম', workers: 'আপনার অধীনে শ্রমিক', emergency: 'জরুরি যোগাযোগ', example: 'উদাহরণ পূরণ করুন', continue: 'প্রোফাইল তৈরি করুন', back: 'পিছনে', demo: 'শুধু প্রোটোটাইপ — বাস্তব নিবন্ধন, পেমেন্ট, বিমা বা পেরোল করা হয় না।', skillExample: 'উদাহরণ: রাজমিস্ত্রি', nameExample: 'উদাহরণ: রবি কুমার', qualificationExample: 'উদাহরণ: ITI / ডিপ্লোমা / দশম শ্রেণি', locationExample: 'উদাহরণ: মাইসোর, কর্ণাটক', companyExample: 'উদাহরণ: কুমার কনস্ট্রাকশনস', emergencyExample: 'উদাহরণ: সুরেশ কুমার — 9123456780', wageExample: 'উদাহরণ: ₹18,000 / মাস', workersExample: 'উদাহরণ: 12' },
};

const skillGroups = {
  'Construction': ['Mason', 'Construction Labour', 'Plumber', 'Electrician', 'Welder', 'Painter', 'Carpenter', 'Bar Bender', 'Tile Worker', 'Scaffolder', 'Roofer'],
  'Industrial': ['Industrial Labour', 'Factory Worker', 'Machine Operator', 'Fitter', 'Lathe Operator', 'Rigger', 'Industrial Electrician', 'Maintenance Technician', 'Production Worker'],
  'Hospitality & Services': ['Chef', 'Hotel Management', 'Baker', 'Housekeeping', 'Barista', 'Beautician'],
  'Transport & Delivery': ['Driver - Ola/Uber', 'Delivery Driver', 'Auto Driver', 'Truck Driver'],
  'Other': ['Helper', 'Loader', 'Security Guard', 'Caregiver'],
};
const skills = Object.values(skillGroups).flat();

export function RegistrationScreen() {
  const { role, setRole, setScreen, lang, setLang, setWorkerSkill, setMonthlySalary, setRegistrationProfile, showToast } = useApp();
  const [formRole, setFormRole] = useState<Role>(role ?? 'labourer');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [gender, setGender] = useState<Gender>('Prefer not to say');
  const [skill, setSkill] = useState('');
  const [customSkill, setCustomSkill] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [additionalSkills, setAdditionalSkills] = useState('');
  const [experience, setExperience] = useState('');
  const [qualification, setQualification] = useState('');
  const [spokenLanguages, setSpokenLanguages] = useState('');
  const [location, setLocation] = useState('');
  const [monthlyIncome, setMonthlyIncome] = useState('');
  const [company, setCompany] = useState('');
  const [workers, setWorkers] = useState('');
  const [emergency, setEmergency] = useState('');

  const c = registrationCopy[lang];
  const selectedLanguage = useMemo(() => LANGUAGES.find((l) => l.code === lang), [lang]);

  const useExample = () => {
    setName(formRole === 'labourer' ? 'Ravi Kumar' : formRole === 'skilledWorker' ? 'Ananya Sharma' : 'Rajesh Kumar');
    setPhone('9876543210');
    setGender(formRole === 'skilledWorker' ? 'Female' : 'Male');
    setSkill(formRole === 'labourer' ? 'Mason' : formRole === 'skilledWorker' ? 'Chef' : 'Construction Supervisor');
    setCustomSkill('');
    setAdditionalSkills(formRole === 'labourer' ? 'Tile Worker, Bar Bender' : formRole === 'skilledWorker' ? 'Indian Cuisine, Food Safety' : 'Site Management, Safety Supervision');
    setExperience('4 years');
    setQualification(formRole === 'labourer' ? 'ITI - Civil' : formRole === 'skilledWorker' ? 'Hotel Management Certificate' : 'Diploma in Civil Engineering');
    setSpokenLanguages('Kannada, Hindi, English');
    setLocation('Mysuru, Karnataka');
    setMonthlyIncome(formRole === 'labourer' ? '18000' : formRole === 'skilledWorker' ? '24000' : '45000');
    setCompany('Kumar Constructions');
    setWorkers('12');
    setEmergency('Suresh Kumar - 9123456780');
  };

  const validate = () => {
    const next: Record<string, string> = {};
    const nameValue = name.trim();
    const phoneValue = phone.trim();
    const selectedSkill = skill === 'Other' ? customSkill.trim() : skill.trim();

    if (!nameValue) next.name = 'Name is required.';
    else if (!/^[\p{L}\p{M}][\p{L}\p{M}\s.'-]*$/u.test(nameValue)) next.name = 'Name should contain letters and spaces only.';

    if (!/^\d{10}$/.test(phoneValue)) next.phone = 'Mobile number must be exactly 10 digits.';
    if (!selectedSkill) next.skill = skill === 'Other' ? 'Please enter your skill.' : 'Please select a skill.';
    if (!location.trim()) next.location = 'Location is required.';
    if (monthlyIncome.trim() && (!/^\d+(\.\d+)?$/.test(monthlyIncome.trim()) || Number(monthlyIncome) < 0)) next.monthlyIncome = 'Enter a valid monthly income.';
    if (formRole === 'contractor' && workers.trim() && (!/^\d+$/.test(workers.trim()) || Number(workers) < 0)) next.workers = 'Enter a valid whole number of workers.';
    if (emergency.trim() && !/[A-Za-z\p{L}\p{M}].*\d{10}/u.test(emergency.trim())) next.emergency = 'Include a contact name and a 10-digit mobile number.';
    setErrors(next);
    return { valid: Object.keys(next).length === 0, selectedSkill };
  };

  const submit = () => {
    const result = validate();
    if (!result.valid) {
      showToast('Please correct the highlighted registration fields.');
      return;
    }
    const skills = [result.selectedSkill, ...additionalSkills.split(',').map((s) => s.trim()).filter(Boolean)].filter(Boolean);
    const salary = Number(monthlyIncome);
    setRole(formRole);
    setWorkerSkill(result.selectedSkill);
    setMonthlySalary(salary || 0);
    setRegistrationProfile({
      name: name.trim(), phone: phone.trim(), gender, category: formRole === 'skilledWorker' ? 'skilledWorker' : 'labourer', primarySkill: result.selectedSkill, skills: Array.from(new Set(skills)),
      experience: experience.trim(), qualification: qualification.trim(),
      languages: spokenLanguages.split(',').map((item) => item.trim()).filter(Boolean), location: location.trim(),
      monthlyIncome: salary || 0, company: company.trim() || undefined, workersManaged: Number(workers) || undefined,
      emergencyContact: emergency.trim(),
    });
    showToast('Demo profile created — your ShramaID is ready.');
    setScreen(formRole === 'labourer' || formRole === 'skilledWorker' ? 'shramId' : 'home');
  };

  return (
    <div className="px-5 pt-6 pb-28 max-w-3xl mx-auto">
      <ScreenHeader title={c.title} subtitle={c.subtitle} />

      <Card className="p-4 mb-4 border border-brand-100 bg-brand-50/60">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-white text-brand-600 flex items-center justify-center flex-shrink-0"><Globe2 size={20} /></div>
          <div className="flex-1">
            <p className="font-bold text-gray-900 text-sm">{c.language}</p>
            <p className="text-xs text-gray-500 mt-1">{selectedLanguage?.nativeLabel} — labels and examples can be read in your selected regional language.</p>
            <div className="mt-3 flex gap-2 overflow-x-auto no-scrollbar pb-1">
              {LANGUAGES.map((l) => (
                <button key={l.code} onClick={() => setLang(l.code)} className={`flex-shrink-0 px-3 py-2 rounded-xl text-xs font-bold border ${lang === l.code ? 'bg-brand-600 text-white border-brand-600' : 'bg-white text-gray-600 border-gray-200'}`}>
                  {l.nativeLabel}
                </button>
              ))}
            </div>
          </div>
        </div>
      </Card>

      <Card className="p-4 mb-4">
        <p className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-3">{c.chooseRole}</p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          <button onClick={() => setFormRole('labourer')} className={`p-4 rounded-2xl border text-left ${formRole === 'labourer' ? 'border-brand-500 bg-brand-50' : 'border-gray-200 bg-white'}`}>
            <UserRound size={20} className={formRole === 'labourer' ? 'text-brand-600' : 'text-gray-400'} />
            <p className="font-bold text-gray-900 mt-2">{c.labourer}</p>
          </button>
          <button onClick={() => setFormRole('contractor')} className={`p-4 rounded-2xl border text-left ${formRole === 'contractor' ? 'border-accent-500 bg-accent-50' : 'border-gray-200 bg-white'}`}>
            <BriefcaseBusiness size={20} className={formRole === 'contractor' ? 'text-accent-600' : 'text-gray-400'} />
            <p className="font-bold text-gray-900 mt-2">{c.contractor}</p>
          </button>
          <button onClick={() => setFormRole('skilledWorker')} className={`p-4 rounded-2xl border text-left ${formRole === 'skilledWorker' ? 'border-purple-500 bg-purple-50' : 'border-gray-200 bg-white'}`}>
            <BriefcaseBusiness size={20} className={formRole === 'skilledWorker' ? 'text-purple-600' : 'text-gray-400'} />
            <p className="font-bold text-gray-900 mt-2">Skilled Worker</p>
            <p className="text-xs text-gray-500 mt-1">Chef, driver, hotel & other skilled jobs</p>
          </button>
        </div>
      </Card>

      <div className="flex justify-end mb-3">
        <button onClick={useExample} className="text-xs font-bold text-brand-600 flex items-center gap-1"><CheckCircle2 size={14} /> {c.example}</button>
      </div>

      <Card className="p-5 space-y-4">
        <Field label={c.fullName} icon={<UserRound size={16} />} value={name} onChange={(value) => { setName(value); setErrors((prev) => ({ ...prev, name: '' })); }} placeholder={c.nameExample} error={errors.name} />
        <Field label={c.phone} icon={<Phone size={16} />} value={phone} onChange={(value) => { setPhone(value.replace(/\D/g, '').slice(0, 10)); setErrors((prev) => ({ ...prev, phone: '' })); }} placeholder="Example: 9876543210" inputMode="tel" maxLength={10} error={errors.phone} />
        <div>
          <label className="block text-xs font-bold text-gray-600 mb-1.5">Gender</label>
          <select value={gender} onChange={(e) => setGender(e.target.value as Gender)} className="w-full px-3.5 py-3 rounded-xl border border-gray-200 bg-gray-50 text-sm text-gray-900 outline-none focus:ring-2 focus:ring-brand-200 focus:border-brand-400">
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Non-binary">Non-binary</option>
            <option value="Prefer not to say">Prefer not to say</option>
          </select>
        </div>
        <div>
          <label className="block text-xs font-bold text-gray-600 mb-1.5"><span className="inline-flex items-center gap-1.5"><BriefcaseBusiness size={16} />{c.skill}</span></label>
          <select value={skill} onChange={(e) => { setSkill(e.target.value); setErrors((prev) => ({ ...prev, skill: '' })); }} className={`w-full px-3.5 py-3 rounded-xl border ${errors.skill ? 'border-error-400 bg-error-50' : 'border-gray-200 bg-gray-50'} text-sm text-gray-900 outline-none focus:ring-2 focus:ring-brand-200 focus:border-brand-400`}>
            <option value="">Select your skill</option>
            {Object.entries(skillGroups).map(([group, groupSkills]) => <optgroup key={group} label={group}>{groupSkills.map((item) => <option key={item} value={item}>{item}</option>)}</optgroup>)}
            <option value="Other">Other — enter my skill</option>
          </select>
          {skill === 'Other' && <div className="mt-2"><Field label="Your skill" value={customSkill} onChange={(value) => { setCustomSkill(value); setErrors((prev) => ({ ...prev, skill: '' })); }} placeholder="Example: Solar Panel Technician" error={errors.skill} /></div>}
          {skill !== 'Other' && errors.skill && <p className="text-xs text-error-600 font-semibold mt-1.5">{errors.skill}</p>}
        </div>
        <Field label="Other / additional skills" value={additionalSkills} onChange={setAdditionalSkills} placeholder="Example: Tile Worker, Bar Bender, Shuttering" />
        <p className="text-[11px] text-gray-400 -mt-2">Add multiple skills separated by commas. Insurance recommendations use all skills entered.</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Field label={c.experience} value={experience} onChange={setExperience} placeholder="Example: 4 years" />
          <Field label={c.qualification} icon={<GraduationCap size={16} />} value={qualification} onChange={setQualification} placeholder={c.qualificationExample} />
        </div>
        <Field label={c.languages} icon={<Languages size={16} />} value={spokenLanguages} onChange={setSpokenLanguages} placeholder="Example: Kannada, Hindi" />
        <Field label={c.location} icon={<MapPin size={16} />} value={location} onChange={(value) => { setLocation(value); setErrors((prev) => ({ ...prev, location: '' })); }} placeholder={c.locationExample} error={errors.location} />
        <Field label={c.wage} value={monthlyIncome} onChange={(value) => { setMonthlyIncome(value.replace(/[^0-9.]/g, '')); setErrors((prev) => ({ ...prev, monthlyIncome: '' })); }} placeholder={c.wageExample} inputMode="numeric" error={errors.monthlyIncome} />
        {formRole === 'contractor' && <>
          <Field label={c.company} value={company} onChange={setCompany} placeholder={c.companyExample} />
          <Field label={c.workers} value={workers} onChange={(value) => { setWorkers(value.replace(/\D/g, '')); setErrors((prev) => ({ ...prev, workers: '' })); }} placeholder={c.workersExample} inputMode="numeric" error={errors.workers} />
        </>}
        <Field label={c.emergency} icon={<Phone size={16} />} value={emergency} onChange={(value) => { setEmergency(value); setErrors((prev) => ({ ...prev, emergency: '' })); }} placeholder={c.emergencyExample} error={errors.emergency} />
      </Card>


      <div className="flex gap-3 mt-5">
        <Button variant="ghost" className="flex-1" onClick={() => { setRole(null); setScreen('home'); }}><ArrowLeft size={16} className="mr-2" />{c.back}</Button>
        <Button className="flex-[2]" onClick={submit}>{c.continue}<ArrowRight size={16} className="ml-2" /></Button>
      </div>
    </div>
  );
}

function Field({ label, value, onChange, placeholder, icon, inputMode, list, error, maxLength }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string; icon?: ReactNode; inputMode?: 'text' | 'tel' | 'numeric'; list?: string; error?: string; maxLength?: number }) {
  return (
    <label className="block">
      <span className="text-xs font-bold text-gray-600 flex items-center gap-1.5 mb-1.5">{icon}{label}</span>
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} inputMode={inputMode} list={list} maxLength={maxLength} className={`w-full px-3.5 py-3 rounded-xl border ${error ? 'border-error-400 bg-error-50' : 'border-gray-200 bg-gray-50'} text-sm text-gray-900 outline-none focus:ring-2 focus:ring-brand-200 focus:border-brand-400`} />
      {error && <span className="block text-xs font-semibold text-error-600 mt-1.5">{error}</span>}
    </label>
  );
}
