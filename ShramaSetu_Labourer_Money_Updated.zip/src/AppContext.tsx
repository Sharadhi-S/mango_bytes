import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from 'react';
import type {
  Role,
  ScreenId,
  EarningEntry,
  SavingsGoal,
  JobListing,
  Conversation,
  AttendanceRow,
  WageRow,
  PostedJob,
  ChatMessage,
  RegistrationProfile,
  WorkerAvailability,
  DailyWorkStatus,
} from './types';
import {
  initialEarnings,
  initialSavingsGoals,
  initialJobs,
  initialConversations,
  initialAttendance,
  initialWages,
  initialPostedJobs,
  workerStats as initialWorkerStats,
} from './mockData';
import { t as translate, type LangCode } from './i18n';

interface WorkerStats {
  todayEarnings: number;
  monthlyEarnings: number;
  availableBalance: number;
  emergencySavings: number;
  currentJob: string;
  currentEmployer: string;
}

interface Toast {
  id: number;
  message: string;
}

interface AppContextValue {
  role: Role | null;
  setRole: (r: Role | null) => void;
  screen: ScreenId;
  setScreen: (s: ScreenId) => void;
  goBack: () => void;
  lang: LangCode;
  setLang: (l: LangCode) => void;
  t: (key: string) => string;
  toasts: Toast[];
  showToast: (message: string) => void;
  voiceActive: boolean;
  voiceText: string;
  playVoice: (text?: string) => void;
  stopVoice: () => void;

  // worker state
  earnings: EarningEntry[];
  savingsGoals: SavingsGoal[];
  jobs: JobListing[];
  conversations: Conversation[];
  workerStats: WorkerStats;
  saveMoney: (goalId: string, amount: number) => void;
  applyJob: (jobId: string) => void;
  sendMessage: (conversationId: string, text: string, attachment?: ChatMessage['attachment']) => void;
  markConversationRead: (conversationId: string) => void;
  transferToBank: () => void;

  // contractor state
  attendance: AttendanceRow[];
  wages: WageRow[];
  postedJobs: PostedJob[];
  setAttendanceStatus: (id: string, status: 'present' | 'absent' | 'half') => void;
  markWagePaid: (id: string) => void;
  postJob: (job: Omit<PostedJob, 'id'>) => void;
  workerSkill: string;
  setWorkerSkill: (skill: string) => void;
  monthlySalary: number;
  setMonthlySalary: (salary: number) => void;
  registrationProfile: RegistrationProfile | null;
  setRegistrationProfile: (profile: RegistrationProfile, options?: { showWellbeing?: boolean }) => void;
  showWellbeingAlertNow: () => void;
  availability: WorkerAvailability;
  dailyWorkStatus: DailyWorkStatus;
  setAvailability: (value: WorkerAvailability) => void;
  setDailyWorkStatus: (value: DailyWorkStatus) => void;
  wellbeingAlertOpen: boolean;
  dismissWellbeingAlert: () => void;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [role, setRoleState] = useState<Role | null>(null);
  const [screen, setScreenState] = useState<ScreenId>('home');
  const [screenHistory, setScreenHistory] = useState<ScreenId[]>([]);

  const setRole = useCallback((nextRole: Role | null) => {
    setRoleState(nextRole);
    setScreenHistory([]);
  }, []);
  const [workerSkill, setWorkerSkill] = useState('Mason');
  const [monthlySalary, setMonthlySalary] = useState(18000);
  const [registrationProfile, setRegistrationProfileState] = useState<RegistrationProfile | null>(null);
  const [availability, setAvailability] = useState<WorkerAvailability>('available');
  const [dailyWorkStatus, setDailyWorkStatus] = useState<DailyWorkStatus>('workDone');
  const [wellbeingAlertOpen, setWellbeingAlertOpen] = useState(false);

  const wellbeingIntervalMs = 20 * 60 * 1000;
  const wellbeingStorageKey = 'shrama-wellbeing-last-shown';

  const showWellbeingAlertNow = useCallback(() => {
    const now = Date.now();
    setWellbeingAlertOpen(true);
    localStorage.setItem(wellbeingStorageKey, String(now));
  }, []);

  // Registration and sign-in both use this setter, so the wellbeing reminder is
  // guaranteed to appear immediately after either successful account entry.
  const setRegistrationProfile = useCallback((profile: RegistrationProfile, options?: { showWellbeing?: boolean }) => {
    setRegistrationProfileState(profile);
    if (options?.showWellbeing !== false) showWellbeingAlertNow();
  }, [showWellbeingAlertNow]);

  useEffect(() => {
    if (!registrationProfile) return;

    const checkReminder = () => {
      const lastShown = Number(localStorage.getItem(wellbeingStorageKey) || 0);
      if (lastShown && Date.now() - lastShown >= wellbeingIntervalMs) {
        showWellbeingAlertNow();
      }
    };

    const intervalId = window.setInterval(checkReminder, 30 * 1000);
    return () => window.clearInterval(intervalId);
  }, [registrationProfile, showWellbeingAlertNow]);

  const dismissWellbeingAlert = useCallback(() => setWellbeingAlertOpen(false), []);
  const [lang, setLang] = useState<LangCode>(() => (localStorage.getItem('shrama-lang') as LangCode) || 'en');
  const changeLang = useCallback((value: LangCode) => { setLang(value); localStorage.setItem('shrama-lang', value); }, []);

  const setScreen = useCallback((next: ScreenId) => {
    setScreenState((current) => {
      if (current === next) return current;
      setScreenHistory((history) => [...history, current]);
      return next;
    });
  }, []);

  const goBack = useCallback(() => {
    setScreenHistory((history) => {
      if (!history.length) {
        setScreenState('home');
        return history;
      }
      const previous = history[history.length - 1];
      setScreenState(previous);
      return history.slice(0, -1);
    });
  }, []);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [voiceActive, setVoiceActive] = useState(false);
  const [voiceText, setVoiceText] = useState('');

  const [earnings] = useState<EarningEntry[]>(initialEarnings);
  const [savingsGoals, setSavingsGoals] = useState<SavingsGoal[]>(initialSavingsGoals);
  const [jobs, setJobs] = useState<JobListing[]>(initialJobs);
  const [conversations, setConversations] = useState<Conversation[]>(initialConversations);
  const [workerStats, setWorkerStats] = useState<WorkerStats>(initialWorkerStats);

  const [attendance, setAttendance] = useState<AttendanceRow[]>(initialAttendance);
  const [wages, setWages] = useState<WageRow[]>(initialWages);
  const [postedJobs, setPostedJobs] = useState<PostedJob[]>(initialPostedJobs);

  const t = useCallback((key: string) => translate(lang, key), [lang]);

  const showToast = useCallback((message: string) => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { id, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((toast) => toast.id !== id));
    }, 3000);
  }, []);

  const playVoice = useCallback((text?: string) => {
    const narration = text || translate(lang, 'voiceIntro');
    setVoiceText(narration);
    setVoiceActive(true);
  }, [lang]);

  const stopVoice = useCallback(() => {
    setVoiceActive(false);
  }, []);

  const saveMoney = useCallback((goalId: string, amount: number) => {
    setSavingsGoals((prev) =>
      prev.map((g) => (g.id === goalId ? { ...g, current: g.current + amount } : g))
    );
    setWorkerStats((prev) => ({
      ...prev,
      availableBalance: prev.availableBalance - amount,
      emergencySavings:
        goalId === 'emergency' ? prev.emergencySavings + amount : prev.emergencySavings,
    }));
  }, []);

  const applyJob = useCallback((jobId: string) => {
    setJobs((prev) => prev.map((j) => (j.id === jobId ? { ...j, applied: true } : j)));
  }, []);

  const sendMessage = useCallback((conversationId: string, text: string, attachment?: ChatMessage['attachment']) => {
    const now = new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    const newMsg: ChatMessage = { id: `m-${Date.now()}`, sender: role === 'contractor' || role === 'employer' ? 'contractor' : 'worker', text, time: now, attachment };
    setConversations((prev) =>
      prev.map((c) =>
        c.id === conversationId
          ? { ...c, messages: [...c.messages, newMsg], lastMessage: text, time: now, unread: 0 }
          : c
      )
    );
  }, [role]);

  const markConversationRead = useCallback((conversationId: string) => {
    setConversations((prev) =>
      prev.map((conversation) => conversation.id === conversationId ? { ...conversation, unread: 0 } : conversation)
    );
  }, []);

  const transferToBank = useCallback(() => {
    showToast(translate(lang, 'toastTransferBank'));
    setTimeout(() => showToast(translate(lang, 'toastTransferDone')), 1000);
  }, [lang, showToast]);

  const setAttendanceStatus = useCallback((id: string, status: 'present' | 'absent' | 'half') => {
    setAttendance((prev) =>
      prev.map((a) => {
        if (a.id !== id) return a;
        const hours = status === 'present' ? 8 : status === 'half' ? 4 : 0;
        return { ...a, status, hours };
      })
    );
  }, []);

  const markWagePaid = useCallback((id: string) => {
    setWages((prev) => prev.map((w) => (w.id === id ? { ...w, status: 'paid' } : w)));
  }, []);

  const postJob = useCallback((job: Omit<PostedJob, 'id'>) => {
    setPostedJobs((prev) => [{ ...job, id: `pj-${Date.now()}` }, ...prev]);
  }, []);

  return (
    <AppContext.Provider
      value={{
        role,
        setRole,
        screen,
        setScreen,
        goBack,
        lang,
        setLang: changeLang,
        t,
        toasts,
        showToast,
        voiceActive,
        voiceText,
        playVoice,
        stopVoice,
        earnings,
        savingsGoals,
        jobs,
        conversations,
        workerStats,
        saveMoney,
        applyJob,
        sendMessage,
        markConversationRead,
        transferToBank,
        attendance,
        wages,
        postedJobs,
        setAttendanceStatus,
        markWagePaid,
        postJob,
        workerSkill,
        setWorkerSkill,
        monthlySalary,
        setMonthlySalary,
        registrationProfile,
        setRegistrationProfile,
        availability,
        dailyWorkStatus,
        setAvailability,
        setDailyWorkStatus,
        wellbeingAlertOpen,
        dismissWellbeingAlert,
        showWellbeingAlertNow,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
