import { useEffect, useMemo, useState } from 'react';
import { Bot, MessageCircle, Send, X, ExternalLink, FileText, Languages, MonitorPlay } from 'lucide-react';
import { useApp } from '@/AppContext';
import { Card } from './ui';

const videoLinks = [
  { label: 'Chef: recipe & kitchen technique demos', query: 'professional chef new recipe tutorial' },
  { label: 'Driver: defensive driving & customer service', query: 'professional driver defensive driving customer service' },
  { label: 'Hotel: front-office & hospitality skills', query: 'hotel management hospitality training tutorial' },
  { label: 'Computer: Excel & digital basics', query: 'computer basics excel beginner tutorial' },
].map((item) => ({ ...item, url: `https://www.youtube.com/results?search_query=${encodeURIComponent(item.query)}` }));

export function AIChatbot() {
  const { role, registrationProfile, workerSkill } = useApp();
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([{ from: 'bot' as const, text: role === 'skilledWorker' ? 'Hi! I’m your ShramaSetu Skilled Worker AI Coach. I can help you build a resume, practise languages, learn computer skills, prepare for interviews, or follow profession-specific demo videos.' : 'Hi! I’m ShramaSetu AI Assistant (prototype). Ask me about registration, jobs, insurance, performance pay, skills, languages or your profile.' }]);

  useEffect(() => {
    const openCoach = () => setOpen(true);
    window.addEventListener('open-shramasetu-ai', openCoach);
    return () => window.removeEventListener('open-shramasetu-ai', openCoach);
  }, []);

  const profileName = registrationProfile?.name || 'there';
  const profession = registrationProfile?.primarySkill || workerSkill || 'your profession';
  const suggestions = useMemo(() => {
    if (role === 'skilledWorker') return ['Help me make a resume', 'Create my career roadmap', 'Teach me computer basics', `Prepare me like an intern for ${profession}`];
    return role === 'labourer' ? ['Which insurance is mandatory for me?', 'How is my performance pay calculated?', 'How can I find jobs?', 'How do I use UPI or my bank account?'] : ['How do I register workers?', 'How can I find workers?', 'How is performance pay calculated?'];
  }, [role, profession]);

  const answer = (question: string) => {
    const q = question.toLowerCase();
    if (role === 'skilledWorker') {
      if (q.includes('resume') || q.includes('cv')) return `Resume Coach: you do not need a corporate-style CV to be discoverable. Start with your name, ${profession}, practical skills, certifications, languages, location, experience and 2–3 real work examples. ShramaSetu can turn those details into a simple job-ready profile and resume.`;
      if (q.includes('roadmap') || q.includes('career') || q.includes('goal')) return `Career Roadmap for ${profession}: 1) strengthen your core practical skill, 2) complete one short industry course or micro-credential, 3) practise communication/computer skills, 4) complete a small real-world task, 5) update your ShramaID evidence, and 6) apply for better local roles. Progress can be tracked step by step so you can see what to do next.`;
      if (q.includes('save') || q.includes('spend') || q.includes('money')) return 'Smart money nudge: connect your savings goal to your career roadmap. Before an unnecessary expense, compare it with the amount needed for your emergency fund, course fee or career goal. The prototype can show reminders and progress without blocking your spending.';
      if (q.includes('language') || q.includes('english') || q.includes('hindi') || q.includes('kannada')) return 'Language Coach: practise a 10-minute routine — greetings, workplace vocabulary, customer conversations, safety instructions and a short interview answer. You can repeat the same lesson in English, Hindi, Kannada, Tamil, Telugu, Marathi or Bengali.';
      if (q.includes('computer') || q.includes('coding') || q.includes('excel')) return 'Computer Coach: begin with typing, email, file management, browser safety, online forms and Excel/Sheets. For technical roles, I can also explain basic programming concepts step by step.';
      if (q.includes('intern') || q.includes('demo') || q.includes('practice') || q.includes('prepare')) return `Intern Mode for ${profession}: learn one concept, watch a demo, complete a small practice task, then self-check with a short quiz. For a chef, for example, practise mise en place, recipe costing, food safety and one new recipe.`;
      if (q.includes('video') || q.includes('youtube') || q.includes('recipe')) return 'I added profession-focused YouTube learning searches below. Choose the closest topic and review the video before practising safely.';
      return `I can coach you for ${profession} with a resume-free profile, career roadmap, short-course preparation, languages, computer skills, interview practice and internship-style tasks.`;
    }
    if (q.includes('insurance') || q.includes('insur')) return `Based on your prototype profile (${registrationProfile?.skills?.join(', ') || workerSkill || 'your selected skill'}), the Insurance page analyses the skills you entered and marks relevant protection as mandatory. You can review the prototype plans there.`;
    if (q.includes('performance') || q.includes('pay') || q.includes('bonus')) return 'ShramaSetu prototype pay protects the agreed base wage, then adds a transparent performance bonus from attendance/reliability, task completion, quality, safety, teamwork and punctuality. Overtime is added separately.';
    if (q.includes('job') || q.includes('work')) return role === 'labourer' ? 'Open Jobs to browse work opportunities and apply. Your profile skills can be used to match you with suitable work.' : 'Use Find Workers to browse workers, or Post Job to create a new requirement.';
    if (q.includes('upi') || q.includes('bank') || q.includes('money') || q.includes('scan') || q.includes('account')) return 'Open Money to see your demo UPI ID, Scan & Pay flow, bank account, transfers, recent activity and savings. These controls are prototype-only and do not move real money.';
    if (q.includes('language') || q.includes('regional')) return 'You can choose your preferred regional language during registration. You can also type your personal details directly in that language.';
    if (q.includes('skill')) return 'Add your primary skill and any additional skills separated by commas. The prototype uses all skills for matching and insurance recommendations.';
    if (q.includes('profile') || q.includes('name')) return `Your prototype profile is for ${profileName}. Details shown after registration come from the information you entered.`;
    return 'I can help with registration, skills, insurance, performance pay, jobs, wages, languages and profile questions. Try one of the suggested questions.';
  };

  const send = (text = input) => {
    const clean = text.trim();
    if (!clean) return;
    setMessages((prev) => [...prev, { from: 'user' as const, text: clean }, { from: 'bot' as const, text: answer(clean) }]);
    setInput('');
  };

  if (!role) return null;

  return <>
    {open && <div className="fixed right-4 bottom-20 z-[60] w-[min(390px,calc(100vw-2rem))]">
      <Card className="overflow-hidden shadow-float border border-gray-100">
        <div className="bg-gray-900 text-white p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-brand-500 flex items-center justify-center"><Bot size={21} /></div>
          <div className="flex-1"><p className="font-extrabold text-sm">{role === 'skilledWorker' ? 'Skilled Worker AI Coach' : 'ShramaSetu AI Assistant'}</p><p className="text-[11px] text-gray-300">Prototype guidance only</p></div>
          <button onClick={() => setOpen(false)} className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center"><X size={17} /></button>
        </div>
        <div className="max-h-80 overflow-y-auto p-3 space-y-2 bg-gray-50">
          {messages.map((m, i) => <div key={i} className={`flex ${m.from === 'user' ? 'justify-end' : 'justify-start'}`}><div className={`max-w-[88%] rounded-2xl px-3 py-2 text-xs ${m.from === 'user' ? 'bg-brand-600 text-white' : 'bg-white text-gray-700 border border-gray-100'}`}>{m.text}</div></div>)}
          {messages.length === 1 && <div className="flex flex-wrap gap-2 pt-1">{suggestions.map((s) => <button key={s} onClick={() => send(s)} className="px-2.5 py-1.5 rounded-full bg-white border border-gray-200 text-[11px] font-semibold text-gray-600">{s}</button>)}</div>}
          {role === 'skilledWorker' && <div className="mt-3 p-3 rounded-2xl bg-white border border-gray-100"><p className="text-xs font-extrabold text-gray-800 mb-2">Learning links</p><div className="space-y-2">{videoLinks.map((v, i) => <a key={v.label} href={v.url} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-xs font-semibold text-brand-700 hover:underline"><span className="w-7 h-7 rounded-lg bg-brand-50 flex items-center justify-center">{i === 0 ? <FileText size={13} /> : i === 1 ? <Languages size={13} /> : i === 2 ? <MonitorPlay size={13} /> : <ExternalLink size={13} />}</span>{v.label}<ExternalLink size={11} className="ml-auto" /></a>)}</div></div>}
        </div>
        <div className="p-3 border-t border-gray-100 flex gap-2"><input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') send(); }} placeholder="Ask your AI coach..." className="flex-1 min-w-0 px-3 py-2.5 rounded-xl bg-gray-100 text-xs outline-none focus:ring-2 focus:ring-brand-200" /><button onClick={() => send()} className="w-10 h-10 rounded-xl bg-brand-600 text-white flex items-center justify-center"><Send size={16} /></button></div>
      </Card>
    </div>}
    <button onClick={() => setOpen((v) => !v)} className="fixed right-4 bottom-[78px] z-[61] w-14 h-14 rounded-full bg-gray-900 text-white shadow-float flex items-center justify-center active:scale-95 transition-transform" aria-label="Open ShramaSetu AI Coach">{open ? <X size={22} /> : <MessageCircle size={22} />}{!open && <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-brand-500 flex items-center justify-center"><Bot size={12} /></span>}</button>
  </>;
}
